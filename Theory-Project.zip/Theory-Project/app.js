const readline = require("readline").createInterface({
  input: process.stdin,
  output: process.stdout,
});

function isUpperCase(str) {
  if (str[0] == str[0].toLowerCase()) {
    // The character is lowercase
    return false;
  } else {
    // The character is uppercase
    return true;
  }
}

const productionRules = {
  E: "TP",
  P: ["+TP", "e"],
  T: "FR",
  R: ["*FR", "e"],
  F: ["(E)", "i"],
};
console.log("Production Rules");
for (let rule in productionRules) {
  for (let i = 0; i < rule.length; i++) {
    console.log(`${rule}-> ${productionRules[rule]}`);
  }
}
console.log("*****************************");

const Vn = ["R", "B"];
const Vt = ["n", "t", "a", "$", "b"];

console.log("VNs ");
for (const vn of Vn) {
  console.log(vn);
}
console.log("*****************************");
console.log("VTs ");
for (const vt of Vt) {
  console.log(vt);
}
console.log("*****************************");

// First and Follow

const first = {
  E: ["(", "i"],
  P: ["+", "e"],
  T: ["(", "i"],
  R: ["*", "e"],
  F: ["(", "i"],
};

const follow = {
  E: ["$", ")"],
  P: ["$", ")"],
  T: ["+", "$", ")"],
  R: ["+", "$", ")"],
  F: ["*", "+", "$", ")"],
};

// const parsingTable = {};
// for (let vn of Vn) {
//   if (first[vn]) {
//     parsingTable[vn] = productionRules[vn];
//     console.log(vn, first[vn]);
//   }
// }
// console.log(parsingTable);
const parsingTable = {
  E: {
    "(": "TP",
    i: "TP",
  },
  P: {
    "+": "+TP",
    ")": "e",
    $: "e",
  },
  T: {
    "(": "FR",
    i: "FR",
  },
  R: {
    "+": "e",
    "*": "*FR",
    ")": "e",
    $: "e",
  },
  F: {
    "(": "(E)",
    i: "i",
  },
};

console.log(parsingTable);
console.log("*****************************");

// let input = prompt("Enter the expression: ");
readline.question(`Enter your expression: `, (input) => {
  let buffer = input.toString();
  let originalbuffer = buffer;
  let stepCounter = 2;
  const stack = ["$", "E"];
  let action = "";
  let pushStep;
  let popStack;
  let expClone;

  console.log(`Steps     Stack            Buffer         Action`);
  console.log(`Step 1    $                  ${buffer}    push $ into stack`);
  console.log(`Step 2    $E                 ${buffer}    push E into stack`);

  while (true) {
    if (stack.length <= 0 && buffer.length <= 0) {
      console.log(
        "Parsing Complete for",
        originalbuffer,
        "it took ",
        stepCounter,
        " units of time"
      );
      break;
    }
    if (stack[stack.length - 1].toString() === buffer[0]) {
      action = stack.pop();
      expClone = buffer[0];
      buffer = buffer.slice(1);
      action = `pop(${action.toString()}), advance(${expClone}))`;
    } else if (
      isUpperCase(stack[stack.length - 1]) &&
      parsingTable[stack[stack.length - 1]][buffer[0]]
    ) {
      action = `${stack[stack.length - 1]} -> ${
        parsingTable[stack[stack.length - 1]][buffer[0]]
      }`;
      popStack = stack.pop();
      pushStep = parsingTable[popStack][buffer[0]].split("").reverse();
      if (pushStep.toString() === "e") {
        continue;
      } else {
        stack.push(...pushStep);
      }
    } else {
      console.log(
        "Parsing Incomplete for",
        originalbuffer,
        "it was not accepted (Syntax Error)"
      );
      break;
    }

    stepCounter++;
    console.log(`Step ${stepCounter}    ${stack}     ${buffer}    ${action}`);
  }

  readline.close();
});
